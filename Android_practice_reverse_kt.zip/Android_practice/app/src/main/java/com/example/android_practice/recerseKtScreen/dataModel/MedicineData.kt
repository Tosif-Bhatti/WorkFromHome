package com.example.android_practice.recerseKtScreen.dataModel

import android.graphics.drawable.Drawable

data class MedicineData(val medicineName: String,val timeOfTaken: String, val quantity: String, val image: Drawable?)