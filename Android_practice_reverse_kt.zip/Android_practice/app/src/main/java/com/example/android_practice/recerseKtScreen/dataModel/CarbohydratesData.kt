package com.example.android_practice.recerseKtScreen.dataModel

import android.graphics.drawable.Drawable

data class CarbohydratesData(val carbohydratesName: String, val carbohydratesValue: String, val sign: String, val iconCompounds: Int)