package com.example.android_practice.recerseKtScreen.dataModel

import android.graphics.drawable.Drawable

data class WorkOutData(var workTitle: String, val workData: String, val workIcon: Drawable?)
