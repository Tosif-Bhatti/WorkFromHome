package com.example.android_practice.recerseKtScreen.dataModel

data class GlucoseCardData(val compoundsName: String, val glucoseLevel: String, val glucoseState: String)
