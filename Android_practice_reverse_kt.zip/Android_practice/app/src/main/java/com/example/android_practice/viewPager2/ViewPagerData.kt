package com.example.android_practice.viewPager2

import com.example.android_practice.example.classes.A

data class ViewPagerData(var imgList: Int, var description: String) {
}