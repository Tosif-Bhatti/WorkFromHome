package com.example.android_practice.screens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.android_practice.R

class BudgetScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_screen)
    }
}