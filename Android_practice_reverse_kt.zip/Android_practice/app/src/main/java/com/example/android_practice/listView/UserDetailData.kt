package com.example.android_practice.listView

data class UserDetailData(var name: String, var massage: String, var imgId: Int) {
}