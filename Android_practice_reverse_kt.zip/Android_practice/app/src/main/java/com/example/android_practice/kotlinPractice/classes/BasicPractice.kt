package com.example.android_practice.kotlinPractice.classes


fun main() {
    println("Hello")
}