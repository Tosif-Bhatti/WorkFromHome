package com.example.android_practice.recerseKtScreen.dataModel

data class SysData(var sysTitle: String, var sysData: String, var sysDesc: String)
