package com.example.android_practice.uiwidgets

import com.example.android_practice.R

data class CountryDataSource(val image: Int, val name: String)
