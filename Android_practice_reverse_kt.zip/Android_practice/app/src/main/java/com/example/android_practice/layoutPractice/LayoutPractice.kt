package com.example.android_practice.layoutPractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.android_practice.R

class LayoutPractice : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_layout_practice)
    }
}