package com.example.android_practice.recerseKtScreen.dataModel

import android.graphics.drawable.Drawable

data class WalkingData(var titleType: String, var time: String, var distance: String, var description: String, var icon: Drawable?)
